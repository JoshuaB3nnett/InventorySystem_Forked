// Copyright Epic Games, Inc. All Rights Reserved.

#include "InventoryGroup01.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, InventoryGroup01, "InventoryGroup01" );
 